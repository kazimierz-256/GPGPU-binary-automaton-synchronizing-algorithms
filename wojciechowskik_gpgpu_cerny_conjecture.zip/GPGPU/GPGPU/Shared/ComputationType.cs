﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPGPU.Shared
{
    public enum ComputationType
    {
        CPU_Parallel, CPU_Serial, GPU, CPU_GPU_Combined
    }
}
