﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;




[assembly: AssemblyTitle("GPGPU")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("GPGPU")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]




[assembly: ComVisible(false)]


[assembly: Guid("c02c48c9-5fbf-42ab-a79a-0d0b7b8cf4ab")]











[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
