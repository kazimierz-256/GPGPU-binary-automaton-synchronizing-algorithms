﻿using GPGPU.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPGPU.Result_veryfier
{
    public class Verify
    {
        public static bool VerifyValidityOfSynchronizingWord(
            Problem problem,
            ComputationResult computationResult,
            int degreeOfParallelism)
        {
            if (!computationResult.isSynchronizable)
                return true;
            var initialQuery = Enumerable.Range(0, problem.size);
            
            if (degreeOfParallelism > 1)
            {
                initialQuery = initialQuery.AsParallel().AsOrdered().WithDegreeOfParallelism(degreeOfParallelism);
            }

            
            
            
            
            
            
            
            
            
            
            
            

            var distinct = initialQuery.Select(letter =>
            {
                int resultingLetter = letter;
                foreach (var isB in computationResult.shortestSynchronizingWord)
                {
                    resultingLetter = isB ? problem.stateTransitioningMatrixB[resultingLetter]
                    : problem.stateTransitioningMatrixA[resultingLetter];
                }
                return resultingLetter;
            }).Distinct().Count();
            if (distinct != 1)
            {

            }
            return distinct == 1;
        }

        
        
        

        public static bool VerifyCernyConjecture(Problem problem, ComputationResult result) =>
            !result.isSynchronizable
            || result.shortestSynchronizingWord.Length <= (problem.size - 1) * (problem.size - 1);
    }
}
